#include <string>
#include "libArchive1.h"
std::string GetHelloWorld();

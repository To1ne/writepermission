#include "libArchive2.h"
std::string GetHelloWorld() { return GetHello() + std::string("World!\n"); }

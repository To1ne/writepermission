#include <iostream>         // for cout
#include "libArchive2.h"

int main(int argc, char* argv[]) {
   std::cout << GetHelloWorld();
   return 0;
}

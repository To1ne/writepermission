#include <string>
std::string GetHello();